clear; clf;

% ------- Data & Generation
beta = 1/(298.15*1.987*1e-3);
k = 100;
quad = @(Ns, w) fpl_quad(Ns, w*Ns, k);
analytic_well = @(N, w) power(1 - 1./(2*w*N), N);
Ns = [ 2, 3, 4, 5, 7, 10, 13, 18, 25, 34, 47, 64, 87, 119, 161, 219, 297, 403, 546, 740, 1000, ];
min_Ns = min(Ns);
max_Ns = max(Ns);
Ns_analytic = logspace(log10(min_Ns), log10(max_Ns), 200);

% Number of MC samples: 
% 1e6 (million)
% Physical Constants for MC data generation:
% n = 100*beta, T = 298.15, kb = 1.987 * 1e-3
% Lambda Cutoff eps:
% 1e-15

% w = 0.25
for i = 1:length(Ns_analytic)
  FPL_quad_w025(i) = quad(Ns_analytic(i), 0.25);
end
FPL_analytic_w025 = analytic_well(Ns_analytic, 0.25);
FPL_numeric_w025 = [ 0.045813, 0.081463, 0.097638, 0.105256, 0.115810, 0.122233, 0.125363, 0.129811, 0.130510, 0.132975, 0.133286, 0.134921, 0.134641, 0.135787, 0.135133, 0.134901, 0.136947, 0.135293, 0.136173, 0.136425, 0.136693, ];

% w = 0.35
for i = 1:length(Ns_analytic)
  FPL_quad_w035(i) = quad(Ns_analytic(i), .35);
end
FPL_analytic_w035 = analytic_well(Ns_analytic, 0.35);
FPL_numeric_w035 = [ 0.158129, 0.191646, 0.205772, 0.213156, 0.222421, 0.227110, 0.231236, 0.234146, 0.235950, 0.237713, 0.238314, 0.238906, 0.239450, 0.239183, 0.239063, 0.239496, 0.240492, 0.240342, 0.240747, 0.240547, 0.240038, ];

% w = 0.5
for i = 1:length(Ns_analytic)
  FPL_quad_w050(i) = quad(Ns_analytic(i), .5);
end
FPL_analytic_w050 = analytic_well(Ns_analytic, .5);
FPL_numeric_w050 = [ 0.309897, 0.332272, 0.342511, 0.348340, 0.354372, 0.358335, 0.360915, 0.363746, 0.364933, 0.366589, 0.367020, 0.368183, 0.367518, 0.367552, 0.368704, 0.368816, 0.368314, 0.368677, 0.367820, 0.368793, 0.368253, ];

% w = 0.75
for i = 1:length(Ns_analytic)
  FPL_quad_w075(i) = quad(Ns_analytic(i), .75);
end
FPL_analytic_w075 = analytic_well(Ns_analytic, .75);
FPL_numeric_w075 = [ 0.480824, 0.492845, 0.498913, 0.501233, 0.505019, 0.507407, 0.510000, 0.509262, 0.511799, 0.512572, 0.513561, 0.512308, 0.513241, 0.514085, 0.513882, 0.513574, 0.514534, 0.512795, 0.513528, 0.514517, 0.513650, ];

% w = 1.0
for i = 1:length(Ns_analytic)
  FPL_quad_w100(i) = quad(Ns_analytic(i), 1.0);
end
FPL_analytic_w100 = analytic_well(Ns_analytic, 1.0);
FPL_numeric_w100 = [ 0.584934, 0.594128, 0.597199, 0.599229, 0.601476, 0.602814, 0.604279, 0.604293, 0.605232, 0.606018, 0.607059, 0.604906, 0.607057, 0.605943, 0.607004, 0.607175, 0.606093, 0.607301, 0.606521, 0.607681, 0.607695, ];

% w = 2.0
for i = 1:length(Ns_analytic)
  FPL_quad_w200(i) = quad(Ns_analytic(i), 2.0);
end
FPL_analytic_w200 = analytic_well(Ns_analytic, 2.0);
FPL_numeric_w200 = [ 0.772092, 0.775106, 0.775971, 0.776114, 0.776287, 0.777763, 0.777394, 0.778538, 0.778222, 0.777892, 0.778700, 0.778823, 0.778953, 0.779057, 0.778324, 0.779024, 0.778328, 0.779631, 0.778975, 0.779004, 0.778439, ];

% w = 5.0
for i = 1:length(Ns_analytic)
  FPL_quad_w500(i) = quad(Ns_analytic(i), 5.0);
end
FPL_analytic_w500 = analytic_well(Ns_analytic, 5.0);
FPL_numeric_w500 = [ 0.903644, 0.903747, 0.903809, 0.904482, 0.905071, 0.904680, 0.904332, 0.904949, 0.904792, 0.904507, 0.904809, 0.904474, 0.905150, 0.904624, 0.904796, 0.904885, 0.905569, 0.904868, 0.904572, 0.904819, 0.904506, ];

% ----- Plotting
figure(1);
ax = gca;
hold(ax, 'on');

set(ax, 'XScale', 'log', 'YScale', 'log');
xlabel('Number of Substituents');
ylabel('Fraction Physical');
xlim(ax, [2, 1000]);
ylim(ax, [1e-2, 1]);

% Show ticks on both sides
ax.Box = 'on';
ax.XAxis.TickDirection = 'both';
ax.YAxis.TickDirection = 'both';

w025_color = "#7E4794"; % Purple
w035_color = "#36b700"; % Green
w050_color = "#0b81a2"; % Blue
w075_color = "#e25759"; % Red
w100_color = "#59a89c"; % Teal
w200_color = "#9d2c00"; % Dark Red
w500_color = "#f0c571"; % Gold

% Plot numeric data
n025 = plot(Ns, FPL_numeric_w025, 'o', 'MarkerSize',4, "Color",w025_color);
n035 = plot(Ns, FPL_numeric_w035,  'o', 'MarkerSize',4,"Color",w035_color);
n050 = plot(Ns, FPL_numeric_w050, 'o', 'MarkerSize',4, "Color",w050_color);
n075 = plot(Ns, FPL_numeric_w075,  'o', 'MarkerSize',4,"Color",w075_color);
n100 = plot(Ns, FPL_numeric_w100, 'o', 'MarkerSize',4, "Color",w100_color);
n200 = plot(Ns, FPL_numeric_w200, 'o', 'MarkerSize',4, "Color",w200_color);
n500 = plot(Ns, FPL_numeric_w500, 'o', 'MarkerSize',4, "Color",w500_color);

% Plot analytic data
a020 = plot(Ns_analytic, FPL_quad_w025, '-',"Color",w025_color, "LineWidth", 1);
a035 = plot(Ns_analytic, FPL_quad_w035, '-',"Color",w035_color, "LineWidth", 1);
a050 = plot(Ns_analytic, FPL_quad_w050, '-',"Color",w050_color, "LineWidth", 1);
a075 = plot(Ns_analytic, FPL_quad_w075, '-',"Color",w075_color, "LineWidth", 1);
a100 = plot(Ns_analytic, FPL_quad_w100, '-',"Color",w100_color, "LineWidth", 1);
a200 = plot(Ns_analytic, FPL_quad_w200, '-',"Color",w200_color, "LineWidth", 1);
a500 = plot(Ns_analytic, FPL_quad_w500, '-',"Color",w500_color, "LineWidth", 1);

% Plot analytic well data
aw020 = plot(Ns_analytic, FPL_analytic_w025, '--',"Color",w025_color, "LineWidth", 1);
aw035 = plot(Ns_analytic, FPL_analytic_w035, '--',"Color",w035_color, "LineWidth", 1);
aw050 = plot(Ns_analytic, FPL_analytic_w050, '--',"Color",w050_color, "LineWidth", 1);
aw075 = plot(Ns_analytic, FPL_analytic_w075, '--',"Color",w075_color, "LineWidth", 1);
aw100 = plot(Ns_analytic, FPL_analytic_w100, '--',"Color",w100_color, "LineWidth", 1);
aw200 = plot(Ns_analytic, FPL_analytic_w200, '--',"Color",w200_color, "LineWidth", 1);
aw500 = plot(Ns_analytic, FPL_analytic_w500, '--',"Color",w500_color, "LineWidth", 1);

% Save the figure w/o legend
set(1,'PaperSize',[3.25,2.5]);
set(1,'PaperPosition',[0,0,3.25,2.5]); % Match your PaperSize
saveas(1,'/Users/matthewsperanza/Programs/SperanzaPhDVisuals/implicit/plot/figures/pwiseFPL_vs_Ns.pdf')

% Dummy plots for line color
hBlack = plot(nan, nan, '-',"Color",w025_color);
hRed  = plot(nan, nan, '-',"Color",w035_color);
hMagenta = plot(nan, nan, '-',"Color",w050_color);
hBlue = plot(nan, nan, '-',"Color",w075_color);
hGreen = plot(nan, nan, '-',"Color",w100_color);
hCyan = plot(nan, nan, '-',"Color",w200_color);
hYellow = plot(nan, nan, '-',"Color",w500_color);

lgd_color = legend(ax, ...
          [hYellow, hCyan, hGreen, hBlue, hMagenta, hRed, hBlack], ...
          {'5.0', '2.0', '1.0', '0.75', '0.5', '0.35', '0.25'}, ...
          'Location', 'southeast');

title(lgd_color, 'Flat Bottom w');
lgd_color.Units = 'normalized';
lgd_color.AutoUpdate = 'off';

% Dummy plots for line style
hDash = plot(nan, nan, 'k--');
hCircle = plot(nan, nan, 'ko');
hSolid = plot(nan, nan, 'k-');

% copy axis
ax2 = copyobj(ax, gcf);
delete(ax2.Children)      % clear data from duplicate axes
ax2.Visible = 'off';
lgd_lines = legend(ax2, [hDash, hCircle, hSolid], {'Analytic', 'Monte Carlo', 'Quadrature'}, ...
  'Location', 'northwest');
title(lgd_lines, 'Calculation');
hold(ax, 'off');

% Save w/ legend
set(1,'PaperSize',[3.25,2.5]);
set(1,'PaperPosition',[0,0,3.25,2.5]); % Match your PaperSize
saveas(1,'/Users/matthewsperanza/Programs/SperanzaPhDVisuals/implicit/plot/figures/pwiseFPL_vs_Ns_legend.pdf')
