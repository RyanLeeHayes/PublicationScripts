clear; clf;

% ------- Data & Generation
Ns = [ 2, 3, 4, 5, 7, 10, 13, 18, 25, 34, 47, 64, 87, 119, 161, 219, 297, 403, 546, 740, 1000, ];
min_Ns = min(Ns);
max_Ns = max(Ns);

% Number of MC samples:
% 1e6 (million)
% Physical Constants for MC data generation:
% T = 298.15, kb = 1.987 * 1e-3
% Lambda Cutoff eps:
% 1e-2

% c = 5.5
FPL_numeric_c55 = [ 0.444540, 0.284205, 0.171447, 0.098804, 0.030142, 0.004398, 0.000526, 0.000020, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, ];
% c = 5.5, independent
FPL_numeric_inde_c55 = [ 0.443635, 0.283877, 0.260999, 0.239356, 0.204389, 0.174488, 0.155790, 0.135986, 0.120289, 0.105948, 0.092192, 0.080801, 0.070110, 0.057342, 0.044973, 0.030457, 0.015164, 0.001068, 0.000000, 0.000000, 0.000000, ];

% c = 8.5
FPL_numeric_c85 = [ 0.593938, 0.454428, 0.328845, 0.231186, 0.107736, 0.031492, 0.008677, 0.000857, 0.000030, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, ];
% c = 8.5, independent
FPL_numeric_inde_c85 = [ 0.594981, 0.454356, 0.426640, 0.402415, 0.367768, 0.333550, 0.312481, 0.292103, 0.273761, 0.260924, 0.249263, 0.239993, 0.232597, 0.224389, 0.219726, 0.214245, 0.208482, 0.203853, 0.199969, 0.195805, 0.191543, ];

% c = 15.5
FPL_numeric_c155 = [ 0.741633, 0.637955, 0.528479, 0.426241, 0.267592, 0.124492, 0.055060, 0.013343, 0.001681, 0.000102, 0.000001, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, ];
% c = 15.5, independent
FPL_numeric_inde_c155 = [ 0.741437, 0.638615, 0.611598, 0.590775, 0.555525, 0.523383, 0.503154, 0.481007, 0.464093, 0.449151, 0.436767, 0.425333, 0.419369, 0.413132, 0.405778, 0.402106, 0.396987, 0.394069, 0.391839, 0.389368, 0.384980, ];

% ----- Plotting
figure(1);
ax = gca;
hold(ax, 'on');
set(ax, 'XScale', 'log', 'YScale', 'log');
xlabel('Number of Substituents');
ylabel('Fraction Physical');
xlim(ax, [2, 1000]);
ylim(ax, [1e-2, 1]);

% Show ticks on both sides
ax.Box = 'on';
ax.XAxis.TickDirection = 'both';
ax.YAxis.TickDirection = 'both';

c055_color = "#a559aa"; % Purple
c085_color = "#59a89c"; % Teal
c155_color = "#e02b35"; % Red

% Plot numeric data
n55 = plot(Ns, FPL_numeric_c55, '--', "Color", c055_color, "LineWidth", 1);
n85 = plot(Ns, FPL_numeric_c85,  '--', "Color", c085_color, "LineWidth", 1);
n155 = plot(Ns, FPL_numeric_c155, '--', "Color", c155_color, "LineWidth", 1);

n55_inde = plot(Ns, FPL_numeric_inde_c55, '-', "Color", c055_color, "LineWidth", 1);
n85_inde = plot(Ns, FPL_numeric_inde_c85, '-', "Color", c085_color, "LineWidth", 1);
n155_inde = plot(Ns, FPL_numeric_inde_c155, '-', "Color", c155_color, "LineWidth", 1);

% Save w/o legend
set(1,'PaperSize',[3.25,2.5]);
set(1,'PaperPosition',[0,0,3.25,2.5]); % Match your PaperSize
saveas(1,'/Users/matthewsperanza/Programs/SperanzaPhDVisuals/implicit/plot/figures/expFPL_vs_Ns.pdf')

% Dummy plots for line color
hRed = plot(nan, nan, '-', "Color", c055_color);
hBlue = plot(nan, nan, '-', "Color", c085_color);
hGreen = plot(nan, nan, '-', "Color", c155_color);
lgd_color = legend(ax, [hRed, hBlue, hGreen], {'5.5', '8.5', '15.5'}, ...
          'Location', 'southeast');
title(lgd_color, 'Parameter c');
lgd_color.Units = 'normalized';
lgd_color.AutoUpdate = 'off';
% Dummy plots for line style
hDash = plot(nan, nan, '--', 'Color', 'black');
hSolid = plot(nan, nan, '-', 'Color', 'black');
ax2 = copyobj(ax, gcf);
delete(ax2.Children)      % clear data from duplicate axes
ax2.Visible = 'off';
lgd_lines = legend(ax2, [hDash, hSolid], {'None', 'Independent 2'}, ...
                  'Location', 'south');
title(lgd_lines, 'Bias');
hold(ax, 'off');

% Save w/ legend
set(1,'PaperSize',[3.25,2.5]);
set(1,'PaperPosition',[0,0,3.25,2.5]); % Match your PaperSize
saveas(1,'/Users/matthewsperanza/Programs/SperanzaPhDVisuals/implicit/plot/figures/expFPL_vs_Ns_legend.pdf')
