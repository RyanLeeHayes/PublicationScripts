clc; clf; clear;

cutoffs = [0.9000    0.9197    0.9370    0.9519    0.9646    0.9752    0.9837    0.9902    0.9950    0.9980    0.9996    1.0000];

% Average over three trials
% old exp data
c055_FPL = [0.42301     0.39173     0.36083     0.33002     0.29887     0.26637     0.23154     0.19326     0.14948    0.095679    0.022748           0];
c055_std = [0.012735    0.013174    0.013396    0.013278    0.012691    0.011887    0.011297    0.010975    0.010285   0.0076121   0.0019497           0];

% width data
w025_FPL = [0.32867     0.30029      0.2749     0.25252     0.23273     0.21487     0.19818     0.18217      0.1663     0.15013      0.1331     0.11345];
w025_std = [0.030024    0.029562    0.028685    0.027629    0.026255    0.024787    0.023112    0.021374    0.019417    0.017447    0.015505    0.013284];

w035_FPL = [0.47961     0.45042     0.42372     0.39949     0.37748     0.35704     0.33754     0.31844      0.2991     0.27896     0.25711     0.23075];
w035_std = [0.022934    0.023031     0.02296    0.022763    0.022346    0.021784    0.020977     0.02027    0.019273    0.018268    0.016995    0.015388];

w050_FPL = [0.606     0.58056     0.55679     0.53483     0.51466      0.4957     0.47716     0.45869     0.43964     0.41928     0.39665     0.36894];
w050_std = [0.038958     0.04006    0.040962    0.041551    0.042019    0.042194    0.042053    0.041577     0.04073    0.039355    0.037378    0.034822];

w075_FPL = [0.69981     0.67918      0.6597     0.64159     0.62476     0.60877     0.59329     0.57775     0.56171     0.54461     0.52536     0.50134];
w075_std = [0.022356    0.022865     0.02348    0.024219    0.024915    0.025474    0.025879    0.026046    0.025752     0.02519     0.02448    0.023353];


% Prepare data for plotting
figure(1);
ax = gca;
hold(ax, 'on');
hold on;
set(groot, 'DefaultLineMarkerSize', 5);
set(groot, 'defaultTextInterpreter', 'latex');
set(groot, 'defaultAxesTickLabelInterpreter', 'latex');
set(groot, 'defaultLegendInterpreter', 'latex')
ebar=false;
if ebar
  errorbar(cutoffs, c055_FPL, c055_std, '--d', 'DisplayName', 'c=5.5');
  errorbar(cutoffs, w025_FPL, w025_std, '-o', 'DisplayName', 'w=0.25');
  errorbar(cutoffs, w035_FPL, w035_std, '-o', 'DisplayName', 'w=0.35');
  errorbar(cutoffs, w050_FPL, w050_std, '-o', 'DisplayName', 'w=0.5');
  %errorbar(cutoffs, w075_FPL, w075_std, '-o', 'DisplayName', 'w=0.75');
else
  plot(cutoffs, c055_FPL, '-d', 'DisplayName', 'c=5.5');
  plot(cutoffs, w025_FPL, '--o', 'DisplayName', 'w=0.25');
  plot(cutoffs, w035_FPL, '--o', 'DisplayName', 'w=0.35');
  plot(cutoffs, w050_FPL, '--o', 'DisplayName', 'w=0.5');
  %plot(cutoffs, w075_FPL, '--o', 'DisplayName', 'w=0.75');
end

grid on;
% Axis widths and ticks
up = .8;
low = 0; % Just lowest tick, always plotted to zero
tick = .1;
n = (up-low)/tick+1;
disp("Number of ticks: " + num2str(n));
yticks(linspace(low, up, n));
ylim(ax, [0, up]);
% X-axis range
eps_max = 1e-1;
eps_min = 0;
xlim(ax, [1-eps_max, 1-eps_min]);

xlabel('Cutoff (1-$\varepsilon$)', 'Interpreter','latex');
ylabel('FPL', "Interpreter", "latex");

% Save w/o legend
set(1,'PaperSize',[3.25,2.5]);
set(1,'PaperPosition',[0,0,3.25,2.5]); % Match your PaperSize
saveas(1,'/Users/matthewsperanza/Programs/SperanzaPhDVisuals/implicit/plot/figures/fpl_vs_cutoff.pdf')

legend();

% Save w/ legend
set(1,'PaperSize',[3.25,2.5]);
set(1,'PaperPosition',[0,0,3.25,2.5]); % Match your PaperSize
saveas(1,'/Users/matthewsperanza/Programs/SperanzaPhDVisuals/implicit/plot/figures/fpl_vs_cutoff_legend.pdf')
