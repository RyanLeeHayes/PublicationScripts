clear; clf; clc;

widths = [0.25, 0.35, 0.5, 0.75, 1, 2, 5]; 

trans8x8 = [138.369 117.0556667 83.811 59.82333333 49.29 19.54433333 5.273333333]; 
trans24x24 = [39.391 32.11966667 23.33566667 16.52466667 11.869 2.564333333 0];

% this part of the code finds the coefficients of the line of best fit for
% each of the systems
loss = @(in, trans, w) sum((log(trans) - log(in(1).*w.^in(2))).^2);
%loss = @(in, trans, w) sum((trans - in(1).*w.^in(2)).^2);
[c8x8, err8x8] = fminsearch(loss, [10, -1], [], trans8x8, widths);
[c24x24, err24x24] = fminsearch(loss, [10, -1], [], trans24x24(1:end-1), widths(1:end-1)); 

str2 = num2str(c8x8(1), 3) + "w^{" + num2str(c8x8(2), 1) + "}";
str8 = num2str(c24x24(1), 3) + "w^{" + num2str(c24x24(2), 3) + "}";

disp("8x8 Model: " + str2 + ", Error: " + err8x8);
disp("24x24 Model: " + str8 + ", Error: " + err24x24);

x = 0:0.01:5; 

% curves are variations of bx^n
curve8x8 = c8x8(1)*x.^c8x8(2);  
curve24x24 = c24x24(1)*x.^c24x24(2); 
kT = (298.15*1.987*1e-3);
model_ideal = sqrt(kT/(8*pi*7.5))*x.^(-1);

figure(1)
hold on;
xlabel("Width")
ylabel("Transition Rate (ns^{-1})", "Interpreter", "tex");
sub8x8_color = "#7E4794";
sub24x24_color = "#8fd7d7";
plot(widths, trans8x8, '.', "Color", sub8x8_color, "MarkerSize", 8, "DisplayName", "8x8");
plot(widths(1:end-1), trans24x24(1:end-1), '.', "Color", sub24x24_color, "MarkerSize", 8, "DisplayName", "24x24");
%plot(x, model_ideal, 'k--', "LineWidth", 1, "DisplayName", "Theory");
L = legend();
L.AutoUpdate="off";
plot(x, curve8x8, '-', "Color", sub8x8_color, "LineWidth", 1); 
plot(x, curve24x24, '-', "Color", sub24x24_color, "LineWidth", 1);
legend();
grid on;
axis square;
xlim([0 5])
ylim([0 160])
hold off;
set(1,'PaperSize',[3.25,2.5]);
set(1,'PaperPosition',[0,0,3.25,2.5]); % Match your PaperSize
saveas(1,'/Users/matthewsperanza/Programs/SperanzaPhDVisuals/implicit/plot/figures/trans_vs_width_benz.pdf')