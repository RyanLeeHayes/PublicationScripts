% plot the values of the widths with error bars
clear; clf; clc;
close all;

widths = [0.25, 0.35, 0.5, 0.75, 1, 2, 5]; 

% would need to adjust to include your transition data 
% currently have each row as one width, with columns representing the
% different triplicate runs. 
trans2 = [24.3467, 21.6044, 17.7822, 12.8578, 9.9156, 5.1911, 2.0933]; 
trans8 = [18.6444, 17.6044, 14.1956, 10.4267, 7.9333,2.7956,0.14667];
trans22 = [ 23.7852, 20.9244, 16.9067, 4.5422, 4.6889, 0.04, 0.10667];

widths_modified = [0.25, 0.35, 0.5, 0.75, 1, 2, 5];
trans22_modified = [ 23.7852, 20.9244, 16.9067, 13.0978, 10.5852, 5.8756, 2.5];

% this part of the code finds the coefficients of the line of best fit for
% each of the systems 
% modified 8 and 22 sub to only include the widths that got transitions for
% all triplicate runs 
loss = @(in, trans, w) sum((log(trans) - log(in(1).*w.^in(2))).^2);
%loss = @(in, trans, w) sum((trans - in(1).*w.^in(2)).^2);
[c2, err2] = fminsearch(loss, [10, -1], [], trans2, widths);
[c8, err8] = fminsearch(loss, [10, -1], [], trans8, widths); 
[c22, err22] = fminsearch(loss, [10, -1], [], trans22, widths);
[c22_mod, err22_mod] = fminsearch(loss, [10, -1], [], ...
  trans22_modified, widths_modified);

str2 = num2str(c2(1), 3) + "w\^" + num2str(c2(2), 1);
str8 = num2str(c8(1), 3) + "w\^" + num2str(c8(2), 3);
str22 = num2str(c22(1), 3) + "w\^" + num2str(c22(2), 3);
str22_mod = num2str(c22_mod(1), 3) + "w\^" + num2str(c22_mod(2), 3);

disp("2sub: " + str2 + ", Error: " + err2);
disp("8sub: " + str8 + ", Error: " + err8);
disp("22sub: " + str22 + ", Error: " + err22);
disp("22sub modified: " + str22_mod + ", Error: " + err22_mod);

x = 0:0.01:5; 

% curves are variations of bx^n
curve2 = c2(1)*x.^c2(2);  
curve8 = c8(1)*x.^c8(2); 
curve22 = c22(1)*x.^c22(2); 
curve22_mod = c22_mod(1).*x.^c22_mod(2);

figure(1)
hold on;
xlabel("Width")
ylabel("Transition Rate (ns^{-1})", "Interpreter", "tex");
sub2_color = "#7E4794";
sub8_color = "#8fd7d7";
plot(widths, trans2, '.', "Color", sub2_color, "MarkerSize", 8, "DisplayName", "2 sub");
plot(widths, trans8, '.', "Color", sub8_color, "MarkerSize", 8, "DisplayName", "8 sub");
L = legend();
L.AutoUpdate="off";
plot(x, curve2, '-', "Color", sub2_color, "LineWidth", 1); 
plot(x, curve8, '-', "Color", sub8_color, "LineWidth", 1);
legend();
grid on;
axis square;
xlim([0 5])
ylim([0 35])
hold off;
set(1,'PaperSize',[3.25,2.5]);
set(1,'PaperPosition',[0,0,3.25,2.5]); % Match your PaperSize
saveas(1,'/Users/matthewsperanza/Programs/SperanzaPhDVisuals/implicit/plot/figures/trans_vs_width_2_8.pdf')

figure(2)
ax = gca ; 
hold on;
orig_color = "#298c8C";
mod_color = "#800074";
xlabel("Potential Well Width")
ylabel("Transition Rate (ns^{-1})", "Interpreter", "tex");
plot(widths, trans22, '.', "Color", orig_color,"MarkerSize", 8, "DisplayName", "Original")
plot(widths_modified(4:end), trans22_modified(4:end), 'x', "Color", mod_color, "MarkerSize", 4, "DisplayName", "Rerun")
L = legend();
L.AutoUpdate="off";
plot(x, curve22, '-', "Color", orig_color, "LineWidth", 1);
plot(x, curve22_mod, '-', "Color", mod_color, "LineWidth", 1);
grid on;
axis square;
xlim([0 5])
ylim([0 35])
hold off;
% Save the figure - change here

set(2,'PaperSize',[3.25,2.5]);
set(2,'PaperPosition',[0,0,3.25,2.5]); % Match your PaperSize
saveas(2,'/Users/matthewsperanza/Programs/SperanzaPhDVisuals/implicit/plot/figures/trans_vs_width_22.pdf')