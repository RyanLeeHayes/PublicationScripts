#! /usr/bin/env python

import math
import numpy as np
import random

#trials=["trial1", "trial2", "trial3"]
trials=["trial1"]
#widths=["w025_FE.dat", "w035_FE.dat", "w050_FE.dat", "w075_FE.dat", "w100_FE.dat", "w200_FE.dat", "w500_FE.dat"]
widths=["w035_FE.dat"]
patterns=["./%s/width/%s/%s"]
systems = ['solv24x24']

for pattern in patterns:
  for width in widths:
    trial_vals = []
    for trial in trials:
      ddG={}
      for system in systems:
        ddG[system]={}
        sum1=0
        sumx=0
        fp=open(pattern % (system, trial, width),'r')
        for line in fp:
          sum1+=1
          sumx+=float(line.split()[2])
        fp.close()
        avg=sumx/sum1
        fp=open(pattern % (system, trial, width),'r')
        for line in fp:
          i=int(line.split()[0])%8
          j=int(line.split()[1])%8
          if i<j:
            ij=(i,j)
          else:
            ij=(j,i)
          if not ij in ddG[system]:
            ddG[system][ij]=[]
          ddG[system][ij].append(float(line.split()[2])-avg)
        fp.close()
    
      sum1=0
      sumx2=0
      difference=[]
      for i in range(8):
        for j in range(i,8):
          ij=(i,j)
          for k in range(len(ddG[system][ij])):
            for l in range(k+1,len(ddG[system][ij])):
              sum1+=1
              sumx2+=(ddG[system][ij][k]-ddG[system][ij][l])**2
              difference.append(ddG[system][ij][k]-ddG[system][ij][l])
      rms=math.sqrt(sumx2/sum1)
      bsrms=[]
      bssum1=0
      bssumx2=0
      for ibs in range(1000):
        sum1=0
        sumx2=0
        for i in range(len(difference)):
          ri=random.randrange(len(difference))
          sum1+=1
          sumx2+=difference[ri]**2
        bsrms.append(math.sqrt(sumx2/sum1))
        bssum1+=1
        bssumx2+=(bsrms[-1]-rms)**2
      # print(scipy.stats.norm.interval(alpha=0.95)) # should give 1.96
      if not math.isnan(math.sqrt(sumx2/sum1)):
        trial_vals.append(math.sqrt(sumx2/sum1))
      print(f"{trial}: {math.sqrt(sumx2/sum1)} +- {1.96*math.sqrt(bssumx2/bssum1)}")

    if len(trial_vals) != 0:
      trial_ave = np.average(trial_vals)
      trial_std = np.std(trial_vals)
      print(f"{width} average: {trial_ave} +- {trial_std}\n")
  
