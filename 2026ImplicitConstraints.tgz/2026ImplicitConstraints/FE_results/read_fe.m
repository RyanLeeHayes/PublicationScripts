%%%%%% Main Script
clear; clc;

% Systems and associated FE data
% "proteinG2" -> (width)
% "proteinG8" -> (mass, gamma, width)
% "proteinG22" -> (width)
% "solv8x8" -> (mass, gamma, width)
% "solv24x24" -> (width)
system="solv8x8";
param = "width";
block = [8, 8];
total_muts = prod(block);

if param == "gamma"
  % Read gamma files
  directory = "/Users/matthewsperanza/Programs/SperanzaPhDVisuals/implicit/FE/" + system + "/gamma/";
  directory = directory + "trial" + ["1", "2", "3"] + "/";
  vals = "g" + ["005", "010", "050", "100", "200", "400"] + "_FE.dat";
  names = ["0.5", "1", "5", "10", "20", "40"];
  testing = "Gamma";
elseif param == "mass"
  directory = "/Users/matthewsperanza/Programs/SperanzaPhDVisuals/implicit/FE/" + system + "/mass/";
  directory = directory + "trial" + ["1", "2", "3"] + "/";
  vals = "m" + ["075", "100", "150", "200", "400"] + "_FE.dat";
  names = ["7.5", "10", "15", "20", "40"];
  testing = "Mass";
elseif param == "width"
  directory = "/Users/matthewsperanza/Programs/SperanzaPhDVisuals/implicit/FE/" + system + "/width/";
  directory = directory + "trial" + ["1", "2", "3"] + "/";
  vals = "w" + ["025", "035", "050", "075", "100", "200", "500"] + "_FE.dat";
  names = ["0.25", "0.35", "0.5", "0.75", "1", "2", "5"];
  testing = "Width";
end

% (param, trial, dG)
dGs = zeros(length(vals), length(directory), total_muts);
uncs = zeros(length(vals), length(directory), total_muts);
for i = 1:length(vals) % loop over params
  for j = 1:length(directory) % loop over trials
    % Read File
    [C, read] = read_fe_file(directory(j)+vals(i));
    if read
      % Assign array
      dGs(i,j,:) = C{1}; % Store dG values
      uncs(i,j,:) = C{2}; % Store uncertainties
    end
  end
end

% Uncertainties
average_unc_dGs = squeeze(mean(uncs, [2 3]))'; % (param)
disp(testing + ": ");
disp(names);
disp("Average Uncertainties For " + testing + ":")
disp(average_unc_dGs)

% dGs with trials averaged out
trial_average_dGs = squeeze(mean(dGs, 2)); % (param, dGs)
trial_std_dGs = mean(squeeze((std(dGs, 0, 2))), "all");
disp("Average std across trials: " + trial_std_dGs)

% Compute dG values relative to the average of a specific param value
disp("")
relative_to = 3; % Up to 6 for gamma, up to 5 for mass
dGs_min_ref = dGs - reshape(trial_average_dGs(relative_to,:), 1,1,[]);
AUE_ref = squeeze(mean(abs(dGs_min_ref), [2 3]))';
RMSE_ref = squeeze(sqrt(mean(power(dGs_min_ref, 2), [2 3])))';
disp("AUE (dG-dG[" + testing + "=" + names(relative_to) + ", id=" + relative_to + "]):")
disp(AUE_ref);
disp("RMSE (dG-dG[" + testing + "=" + names(relative_to) + ", id=" + relative_to + "]):")
disp(RMSE_ref);

% Compute dG values relative to average of all trials for all params
disp("");
dGs_min_total = dGs - mean(dGs, [1 2]);
big = max(dGs_min_total, [], 'all');
disp("Max error relative to mean: " + big)
AUE_total = squeeze(mean(abs(dGs_min_total), [2 3]))';
RMSE_total = squeeze(sqrt(mean(power(dGs_min_total, 2), [2 3])))';
disp("AUE (dG-ave(dG)): ")
disp(AUE_total);
disp("RMSE (dG-ave(dG)): ")
disp(RMSE_total);

%%%%%% Helper Functions
function [C, read] = read_fe_file(file_name)
    % Read File
    read = true;
    disp("Reading file: " + file_name);
    if(isfile(file_name))
      file = fopen(file_name, 'r');
      pos  = ftell(file);
      line = fgetl(file);
      fseek(file,pos,'bof'); % Rewind

      N = length(strsplit(strtrim(line)))-3;
      format_spec = [repmat('%d ',1,N) '%f %s %f'];
      C = textscan(file, format_spec, 'Delimiter',' ', 'MultipleDelimsAsOne',true);
      C = {C{N+1}, C{N+3}};
      fclose(file);
    else 
      read=false;
      disp("");
      disp("File doesn't exist!!");
      disp("Non-existant file: " + file_name);
      disp("")
      C = "";
    end
end
