#! /usr/bin/env python

import math
import numpy as np
import random

# These don't do anything
trials=["trial1"]
systems=['solv8x8']
# Filenames/paths
widths=["24x24_pwise1.dat"]
patterns=["./ddG_results/%s"]

for pattern in patterns:
  for width in widths:
    trial_ave = 0
    samples=0
    for trial in trials:
      ddG={}
      for system in systems:
        ddG[system]={}
        sum1=0
        sumx=0
        fp=open(pattern % (width),'r')
        for line in fp:
          sum1+=1
          sumx+=float(line.split()[2])
        fp.close()
        avg=sumx/sum1
        fp=open(pattern % (width),'r')
        for line in fp:
          i=int(line.split()[0])%8
          j=int(line.split()[1])%8
          if i<j:
            ij=(i,j)
          else:
            ij=(j,i)
          if not ij in ddG[system]:
            ddG[system][ij]=[]
          ddG[system][ij].append(float(line.split()[2])-avg)
        fp.close()

      sum1=0
      sumx2=0
      difference=[]
      for i in range(8):
        for j in range(i,8):
          ij=(i,j)
          for k in range(len(ddG[system][ij])):
            for l in range(k+1,len(ddG[system][ij])):
              sum1+=1
              sumx2+=(ddG[system][ij][k]-ddG[system][ij][l])**2
              difference.append(ddG[system][ij][k]-ddG[system][ij][l])
      rms=math.sqrt(sumx2/sum1)
      bsrms=[]
      bssum1=0
      bssumx2=0
      for ibs in range(1000):
        sum1=0
        sumx2=0
        for i in range(len(difference)):
          ri=random.randrange(len(difference))
          sum1+=1
          sumx2+=difference[ri]**2
        bsrms.append(math.sqrt(sumx2/sum1))
        bssum1+=1
        bssumx2+=(bsrms[-1]-rms)**2
      # print(scipy.stats.norm.interval(alpha=0.95)) # should give 1.96
      if not math.isnan(math.sqrt(sumx2/sum1)):
        trial_ave += math.sqrt(sumx2/sum1)
        samples += 1
      print(f"{trial}: {math.sqrt(sumx2/sum1)} +- {1.96*math.sqrt(bssumx2/bssum1)}")

    if samples != 0:
      trial_ave /= samples
      print(f"{width} average: {trial_ave}\n")
  
