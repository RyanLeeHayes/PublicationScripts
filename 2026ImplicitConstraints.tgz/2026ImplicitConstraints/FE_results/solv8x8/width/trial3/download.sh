#! /bin/bash

take="C" # e.g. "A" or "B" or "C"
system="8x8"
length=7
widths=("A" "B" "C" "D" "E" "F" "G")
digits=("025" "035" "050" "075" "100" "200" "500")

# Clear existing
echo "rm w*_FE.dat"
rm w*_FE.dat

for (( i = 0; i < $length; i++))
do
  echo "rsync -P --inplace speranzm@hpc3.rcic.uci.edu:/dfs8/rhayes1_lab/ayluong1/implicitconstraints/widthtests/Run${take}${system}Width/${system}Width${widths[$i]}/analysis222/Result.txt ./w${digits[$i]}_FE.dat"
  rsync -P --inplace speranzm@hpc3.rcic.uci.edu:/dfs8/rhayes1_lab/ayluong1/implicitconstraints/widthtests/Run${take}${system}Width/${system}Width${widths[$i]}/analysis222/Result.txt ./w${digits[$i]}_FE.dat
done
