#! /bin/bash

take="C" # e.g. "B" or "C"

length=7
gammas=("0.1" "0.5" "1" "5" "10" "20" "40")
digits=("001" "005" "010" "050" "100" "200" "400")

# Clear existing
echo "rm g*_FE.dat"
rm g*_FE.dat

for (( i = 0; i < $length; i++))
do
  echo "rsync -P --inplace speranzm@hpc3.rcic.uci.edu:/dfs8/rhayes1_lab/ayluong1/implicitconstraints/gammatests/finished/8x8G${gammas[$i]}$take/analysis222/Result.txt ./g${digits[$i]}_FE.dat"
  rsync -P --inplace speranzm@hpc3.rcic.uci.edu:/dfs8/rhayes1_lab/ayluong1/implicitconstraints/gammatests/finished/8x8G${gammas[$i]}$take/analysis222/Result.txt ./g${digits[$i]}_FE.dat
done
