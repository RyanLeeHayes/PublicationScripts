#! /bin/bash

take="C" # e.g. "B" or "C"

length=4
masses=("7.5" "10" "20" "40") # 15 data is in my directory, copy manually
digits=("075" "100" "200" "400")

# Clear existing
echo "rm m*_FE.dat"
rm m*_FE.dat

for (( i = 0; i < $length; i++))
do
  echo "rsync -P --inplace speranzm@hpc3.rcic.uci.edu:/dfs8/rhayes1_lab/ayluong1/implicitconstraints/masstests/8x8W${masses[$i]}/analysis222/Result.txt ./m${digits[$i]}_FE.dat"
  rsync -P --inplace speranzm@hpc3.rcic.uci.edu:/dfs8/rhayes1_lab/ayluong1/implicitconstraints/masstests/8x8W${masses[$i]}/analysis222/Result.txt ./m${digits[$i]}_FE.dat
done
