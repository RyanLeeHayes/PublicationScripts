#! /usr/bin/env python

import math
import numpy as np
import random

# vacuum, solvent, solvation free energy
patterns = ["./%s"]
#systems = ["vac8x8/width/trial1/w035_FE.dat", "vac24x24/width/trial1/w035_FE.dat"]
systems = ["solv8x8/width/trial1/w035_FE.dat", "solv24x24/width/trial1/w035_FE.dat"]
#systems = ["ddG_results/8x8_pwise1.dat", "ddG_results/24x24_pwise1.dat"]

for pattern in patterns:
  ddG={}
  for system in systems:
    ddG[system]={}
    sum1=0
    sumx=0
    fp=open(pattern % system,'r')
    for line in fp:
      sum1+=1
      sumx+=float(line.split()[2])
    fp.close()
    avg=sumx/sum1
    fp=open(pattern % system,'r')
    for line in fp:
      i=int(line.split()[0])%8
      j=int(line.split()[1])%8
      if i<j:
        ij=(i,j)
      else:
        ij=(j,i)
      if not ij in ddG[system]:
        ddG[system][ij]=[]
      ddG[system][ij].append(float(line.split()[2])-avg)
    fp.close()

  sum1=0
  sumx2=0
  difference=[]
  for i in range(8):
    for j in range(i,8):
      ij=(i,j)
      for v8 in ddG[systems[0]][ij]:
        for v24 in ddG[systems[1]][ij]:
          sum1+=1
          sumx2+=(v8-v24)**2
          difference.append(v8-v24)
  rms=math.sqrt(sumx2/sum1)
  bsrms=[]
  bssum1=0
  bssumx2=0
  for ibs in range(1000):
    sum1=0
    sumx2=0
    for i in range(len(difference)):
      ri=random.randrange(len(difference))
      sum1+=1
      sumx2+=difference[ri]**2
    bsrms.append(math.sqrt(sumx2/sum1))
    bssum1+=1
    bssumx2+=(bsrms[-1]-rms)**2
  # print(scipy.stats.norm.interval(alpha=0.95)) # should give 1.96
  
  print(f"{systems[0]} vs. {systems[1]}: \n{math.sqrt(sumx2/sum1)} +- {1.96*math.sqrt(bssumx2/bssum1)}")
