#! /bin/bash

take="2" # e.g. "1" "2" or "3"

length=6
gammas=("0.5" "1" "5" "10" "20" "40")
digits=("005" "010" "050" "100" "200" "400")

# Clear existing
echo "rm g*_FE.dat"
rm g*_FE.dat

for (( i = 0; i < $length; i++))
do
  echo "rsync -P --inplace speranzm@hpc3.rcic.uci.edu:/dfs8/rhayes1_lab/odooley/proteinG/newImpCons/weightsForPaper/gamma/${gammas[$i]}/run$take/analysis226/Result.txt ./g${digits[$i]}_FE.dat"
  rsync -P --inplace speranzm@hpc3.rcic.uci.edu:/dfs8/rhayes1_lab/odooley/proteinG/newImpCons/weightsForPaper/gamma/${gammas[$i]}/run$take/analysis226/Result.txt ./g${digits[$i]}_FE.dat
done
