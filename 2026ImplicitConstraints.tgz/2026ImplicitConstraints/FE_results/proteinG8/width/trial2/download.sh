#! /bin/bash

muts="8"
take="/take2" # e.g. "/take2"

length=7
widths=("0.25" "0.35" "0.5" "0.75" "1" "2" "5")
digits=("025" "035" "050" "075" "100" "200" "500")

# Clear History
echo "rm w*_FE.dat"
rm w*_FE.dat

for (( i = 0; i < $length; i++))
do
  echo "rsync -P --inplace speranzm@hpc3.rcic.uci.edu:/dfs8/rhayes1_lab/odooley/proteinG/newImpCons/widths/${widths[$i]}/${muts}${take}/analysis226/Result.txt ./w${digits[$i]}_FE.dat"
  rsync -P --inplace speranzm@hpc3.rcic.uci.edu:/dfs8/rhayes1_lab/odooley/proteinG/newImpCons/widths/${widths[$i]}/${muts}${take}/analysis226/Result.txt ./w${digits[$i]}_FE.dat
done
