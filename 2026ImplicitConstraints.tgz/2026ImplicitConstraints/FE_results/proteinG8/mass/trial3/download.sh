#! /bin/bash

take="3" # e.g. "1" "2" or "3"

length=5
masses=("7.5" "10" "15" "20" "40")
digits=("075" "100" "150" "200" "400")

# Clear existing
echo "rm m*_FE.dat"
rm m*_FE.dat

for (( i = 0; i < $length; i++))
do
  echo "rsync -P --inplace speranzm@hpc3.rcic.uci.edu:/dfs8/rhayes1_lab/odooley/proteinG/newImpCons/weightsForPaper/${masses[$i]}/8/run$take/analysis226/Result.txt ./m${digits[$i]}_FE.dat"
  rsync -P --inplace speranzm@hpc3.rcic.uci.edu:/dfs8/rhayes1_lab/odooley/proteinG/newImpCons/weightsForPaper/${masses[$i]}/8/run$take/analysis226/Result.txt ./m${digits[$i]}_FE.dat
done
