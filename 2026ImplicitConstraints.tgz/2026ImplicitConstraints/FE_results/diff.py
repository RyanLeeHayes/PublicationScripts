#!/usr/bin/env python3

import sys
import math


def parse_line(line):
    """
    Extract value and uncertainty from a line like:
    0  1  -11.980 +/- 0.060

    Works regardless of how many leading columns exist.
    """
    parts = line.strip().split()

    if len(parts) < 3:
        return None

    try:
        # Value is third from the end
        value = float(parts[-3])
        # Uncertainty is last column
        uncertainty = float(parts[-1])
        # Indices are everything prior to value
        ids = []
        for i in range(len(parts)-3):
            ids.append(int(parts[i])) 

        return ids, value, uncertainty
    except ValueError:
        return None


def read_file(filename):
    ids = []
    values = []
    uncertainties = []

    with open(filename, 'r') as f:
        for line in f:
            parsed = parse_line(line)
            if parsed:
                index, val, err = parsed
                ids.append(index)
                values.append(val)
                uncertainties.append(err)

    return ids, values, uncertainties


def main(file1, file2):
    ids, vals1, errs1 = read_file(file1)
    ids, vals2, errs2 = read_file(file2)

    if len(vals1) != len(vals2):
        print("Error: Files do not have the same number of data lines.")
        sys.exit(1)

    print("Difference (file1 - file2):\n")

    for i in range(len(vals1)):
        diff = vals1[i] - vals2[i]

        # Propagate uncertainty: sqrt(err1^2 + err2^2)
        diff_err = math.sqrt(errs1[i]**2 + errs2[i]**2)
        string = ""
        for j in range(len(ids[i])):
            string = f"{string} {ids[i][j]:4d}"
        print(f"{string} {diff:10.3f} +/- {diff_err:6.3f}")


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python diff_columns.py file1 file2")
        sys.exit(1)

    main(sys.argv[1], sys.argv[2])

