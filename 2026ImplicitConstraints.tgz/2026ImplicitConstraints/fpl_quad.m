function I = fpl_quad(Ns, w, k)
    % w = Ns*width + 1;
    % p(x) =
    %           exp(-beta*.5*k/beta*(x+w)^2)/Z   x <= -w
    %           1/Z                              A < x < B
    %           exp(-beta*.5*k/beta*(x-w)^2)/Z   x >= w
    % beta cancels -> independent of T

    % Normalization constant
    Z = 2*w + sqrt(2*pi/k);

    % PDF and CDF
    p = @(x)     piecewise_pdf(x, w, k, Z);
    F = @(x)     piecewise_cdf(x, w, k, Z);

    % Integrand for θ0
    integrand = @(theta0) p(theta0) .* (F(theta0 - 1.0)).^(Ns-1);

    % Perform integral over (-∞, ∞)
    c = w + 8*(1/sqrt(k)); % Flat bottom width +8 std
    I = Ns*integral(integrand, -c, c);
end

function val = piecewise_pdf(x, w, k, Z)
    val = zeros(size(x));

    left  = x <= -w;
    mid   = x > -w & x < w;
    right = x >= w;

    val(left)  = exp(-0.5*k*(x(left) + w).^2);
    val(mid)   = 1;
    val(right) = exp(-0.5*k*(x(right) - w).^2);

    val = val / Z;
end

function C = piecewise_cdf(x, w, k, Z)
    % \int_{-inf}^{x} exp(-a*(x'-b)^2) = 
    % .5*sqrt(pi/a)*(erf(sqrt(a)*(x-b)) - erf(-inf))
    % erf(-inf) = -1
    % erf(0) = 0

    alpha = sqrt(0.5*k);
    pref  = 0.5*sqrt(pi)/alpha;

    C = zeros(size(x));
    left  = x <= -w;
    mid   = x > -w & x < w;
    right = x >= w;

    % left Gaussian
    C(left) = pref*(erf(alpha*(x(left)+w)) + 1) / Z;
    % plateau
    C(mid) = (pref + x(mid)+w)/Z;
    % right Gaussian
    C(right) = (pref + 2*w + pref*erf(alpha*(x(right)-w))) / Z;
end