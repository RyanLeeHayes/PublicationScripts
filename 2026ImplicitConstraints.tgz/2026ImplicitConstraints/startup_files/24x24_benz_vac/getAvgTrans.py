#!/usr/bin/env python

import numpy as np

nsubs=[22]
nblocks=22
lc = 0.99
step = 226

totalTrans = 0
tags = 5
ns = 15 # remove equil samples
total_ns = ns*tags

for tag in range(tags):
    data=np.loadtxt("analysis"+str(step)+"/data/Lambda."+str(tag)+".0.dat")

    ibuff=0
    for i in range(len(nsubs)):
        trans=np.zeros((nsubs[i],nsubs[i]),dtype='int')
        i_curr=-1
        for t in range(0,data.shape[0]): # row in data:
            i_prev=i_curr
            for j in range(0,nsubs[i]):
                if data[t,j+ibuff]>lc:
                    i_curr=j;
            if i_prev>=0 and i_prev!=i_curr:
                trans[i_prev,i_curr]+=1

        print("Trial %d, site %d" % (tag,i))
        print("Transition matrix")
        print(trans)
        print("Transitions from")
        print(np.sum(trans,axis=1))
        print("Transition to")
        print(np.sum(trans,axis=0))

        ibuff+=nsubs[i]

        totalTrans += np.sum(trans)
        print("Total Transitions: ", np.sum(trans))

print("Average # of transitions over all 5 runs at 1 site: ",totalTrans/total_ns)
