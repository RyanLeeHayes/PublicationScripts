#! /bin/bash

CHARMMEXEC=/dfs8/rhayes1_lab/odooley/CHARMM-v3/gnu/charmm
export FFTW_HOME=$FFTW_DIR
source /dfs8/rhayes1_lab/speranzm/programs/ALF/build/env-alf/bin/activate
module load cmake/3.20.5 cuda/11.7.1 gcc/11.2.0 openmpi/4.1.2/gcc.11.2.0 fftw/3.3.10/gcc.11.2.0-openmpi.4.1.2
export CRITERIA=3.2e-4

# Set slurm options for cluster
export SLURMOPTSMD="--time=1440 --ntasks=1 --tasks-per-node=1 --cpus-per-task=1 -A rhayes1_lab_gpu -p gpu --gres=gpu:1 --export=ALL"
export SLURMOPTSPP="--time=1440 --ntasks=1 --tasks-per-node=1 --cpus-per-task=1 -A rhayes1_lab_gpu -p gpu --gres=gpu:1 --export=ALL"

# Run flattening
DEPEND=""
PID=`sbatch --parsable $SLURMOPTSMD --array=1-3%1 $DEPEND ./runflat.sh`

# Run short production
DEPEND="--dependency=afterok:${PID}_3"
NEWDEPEND="--dependency="
COMMA=""
for p in a b c d e
do
  export step=221
  export p
  export nitt=20
  export imax=5
  PID=`sbatch --parsable $SLURMOPTSMD --array=1-3%1 $DEPEND ./runprod.sh`
  NEWDEPEND="${NEWDEPEND}${COMMA}afterok:${PID}_3"
  COMMA=","
done

# Run postprocessing on short production to optimize biases
DEPEND=$NEWDEPEND
export i=221
export eqS=1
export S=5
export N=5
export skipE=1
PID=`sbatch --parsable $SLURMOPTSPP --array=1-3%1 $DEPEND ./postprocess.sh`

# Run medium production
DEPEND="--dependency=afterok:${PID}_3"
NEWDEPEND="--dependency="
COMMA=""
for p in a b c d e
do
  export step=222
  export p
  export nitt=20
  export imax=5
  PID=`sbatch --parsable $SLURMOPTSMD --array=1-3%1 $DEPEND ./runprod.sh`
  NEWDEPEND="${NEWDEPEND}${COMMA}afterok:${PID}_3"
  COMMA=","
done

# Run postprocessing on medium production to optimize biases
DEPEND=$NEWDEPEND
export i=222
export eqS=1
export S=5
export N=5
export skipE=1
PID=`sbatch --parsable $SLURMOPTSPP --array=1-3%1 $DEPEND ./postprocess.sh`

# Run long production
DEPEND="--dependency=afterok:${PID}_3"
NEWDEPEND="--dependency="
COMMA=""
for p in a b c d e
do
  export step=223
  export p
  export nitt=20
  export imax=5
  PID=`sbatch --parsable $SLURMOPTSMD --array=1-3%1 $DEPEND ./runprod.sh`
  NEWDEPEND="${NEWDEPEND}${COMMA}afterok:${PID}_3"
  COMMA=","
done

# Run postprocessing on long production to optimize biases
DEPEND=$NEWDEPEND
export i=223
export eqS=1
export S=5
export N=5
export skipE=1
PID=`sbatch --parsable $SLURMOPTSPP --array=1-3%1 $DEPEND ./postprocess.sh`

# Run short production
DEPEND="--dependency=afterok:${PID}_3"
NEWDEPEND="--dependency="
COMMA=""
for p in a b c d e
do
  export step=224
  export p
  export nitt=20
  export imax=5
  PID=`sbatch --parsable $SLURMOPTSMD --array=1-3%1 $DEPEND ./runprod.sh`
  NEWDEPEND="${NEWDEPEND}${COMMA}afterok:${PID}_3"
  COMMA=","
done

# Run postprocessing on short production to optimize biases
DEPEND=$NEWDEPEND
export i=224
export eqS=1
export S=5
export N=5
export skipE=1
PID=`sbatch --parsable $SLURMOPTSPP --array=1-3%1 $DEPEND ./postprocess.sh`

# Run medium production
DEPEND="--dependency=afterok:${PID}_3"
NEWDEPEND="--dependency="
COMMA=""
for p in a b c d e
do
  export step=225
  export p
  export nitt=20
  export imax=20
  PID=`sbatch --parsable $SLURMOPTSMD --array=1-3%1 $DEPEND ./runprod.sh`
  NEWDEPEND="${NEWDEPEND}${COMMA}afterok:${PID}_3"
  COMMA=","
done

# Run postprocessing on medium production to optimize biases
DEPEND=$NEWDEPEND
export i=225
export eqS=5
export S=20
export N=5
export skipE=2
PID=`sbatch --parsable $SLURMOPTSPP --array=1-3%1 $DEPEND --mem=30G ./postprocess.sh`

# Run long production
DEPEND="--dependency=afterok:${PID}_3"
NEWDEPEND="--dependency="
COMMA=""
for p in a b c d e
do
  export step=226
  export p
  export nitt=20
  export imax=20
  PID=`sbatch --parsable $SLURMOPTSMD --array=1-3%1 $DEPEND ./runprod.sh`
  NEWDEPEND="${NEWDEPEND}${COMMA}afterok:${PID}_3"
  COMMA=","
done

# Run postprocessing on long production to optimize biases
DEPEND=$NEWDEPEND
export i=226
export eqS=5
export S=20
export N=5
export skipE=2
PID=`sbatch --parsable $SLURMOPTSPP --array=1-3%1 $DEPEND --mem=30G ./postprocess.sh`
