import numpy as np
alf_info={}
alf_info['name']='benz'
alf_info['nsubs']=np.loadtxt('prep/nsubs',dtype='int',ndmin=1)
alf_info['nblocks']=np.sum(alf_info['nsubs'])
alf_info['ncentral']=0
alf_info['nreps']=1
alf_info['nnodes']=1
alf_info['temp']=298.15
alf_info['enginepath']='/dfs8/rhayes1_lab/bin/CHARMM_EXE_20250828debugpwise/gnu/charmm'
alf_info['loss']="nonlinear2024"
alf_info['impcons']="fnpwise2026"
alf_info['impconsopt']={"w": 0.35, "k": 100}
alf_info['bias']='bcxstu2026'
