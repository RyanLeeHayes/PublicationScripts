#! /bin/bash

if [ ! -f variables$(( $i + 1)).inp ]
then
  python -c "import alf; alf.postprocess($i,$eqS,$S,$N,$skipE,True,engine='bladelib',ntersite=[0,0],lc=.99)"
fi
