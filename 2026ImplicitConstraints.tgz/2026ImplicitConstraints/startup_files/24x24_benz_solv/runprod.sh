#!/bin/bash

iend=$(( $SLURM_ARRAY_TASK_ID * $nitt ))
ibeg=$(( $iend - $nitt ))
iend=$(( $iend<$imax ? $iend : $imax ))
ibeg=$(( $ibeg<$imax ? $ibeg : $imax ))
python -c "import alf; alf.runprod($step,'$p',$ibeg,$iend,engine='bladelib')"
