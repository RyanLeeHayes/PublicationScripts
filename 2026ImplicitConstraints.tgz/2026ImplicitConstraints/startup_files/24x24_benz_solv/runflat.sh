#!/bin/bash

python -c "import alf; alf.initialize(engine='bladelib')"
python -c "import alf; alf.runflat(1,200,13000,39000,engine='bladelib',ntersite=[0,0])"
python -c "import alf; alf.runflat(201,220,125000,375000,engine='bladelib',ntersite=[0,0])"
