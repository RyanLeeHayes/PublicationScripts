clear; clc;

w = [0.25, 0.35];
Ns = [2];

beta = 1/(298.15*1.987*1e-3)

% correct intended behavior to what MD engine samples by multiplying by beta
k = 100*beta

disp("Widths:  " + num2str(w))
for i = 1:length(Ns)
  results = zeros(size(w));
  for j = 1:length(w)
    results(j) = fpl_quad(Ns(i), w(j)*Ns(i), k); % Example calculation
  end
  disp("Ns = " + num2str(Ns(i)) + " FPL: " + num2str(results))
end