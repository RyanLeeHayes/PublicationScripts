#include <iostream>	
#include <cmath> 
#include <stdlib.h>
#include <stdio.h>
#include <random> 
#include <utility>
#include <math.h>
#include <random>

using namespace std; 

double random01() {
    static thread_local std::mt19937 gen(std::random_device{}());
    static std::uniform_real_distribution<double> dis(0.0f, 1.0f);
    return dis(gen);
}

int compare_double(const void* a, const void* b) {
	const double* arg1 = (const double*)a;
	const double* arg2 = (const double*)b;
	if (*arg1 < *arg2) return -1;
	if (*arg1 > *arg2) return 1;
	return 0;
}

double findMaxTheta(double* thetas, int nSub) {
	double maxTheta = -1e9;
	for (int i = 1; i < nSub; i++) {
		if (thetas[i] > maxTheta) {
			maxTheta = thetas[i];
		}
	}
	return maxTheta;
}

double f(double* x, double x0, int nSub) {
	double sum = -1;
	double d_sum = 0;
	for (int i = 0; i < nSub; i++) {
        double diff = x[i]-x0;
		double diff2 = diff*diff;
		if (diff >= 0) {
			sum += diff*diff2;
			d_sum -= 3*diff2; 
		}
	}
	return sum/d_sum;
} 

double newtonsMethod(double x0, int* iter, double* thetas, int nSub, double tolerance = 1e-12, int maxIter = 100) {
	int newtonsIter = 0; 
	double y_yPrime = 0; 
	bool one_more = false;
	while (newtonsIter < maxIter) {
		newtonsIter++; 
		y_yPrime = f(thetas, x0, nSub);
		double x1 = x0 - y_yPrime; 
		double difference = x1 - x0; 
		if(one_more){
			break;
		}
		if (abs(difference) < tolerance) {
			one_more = true;
		}
		x0 = x1; 
	}
	if(newtonsIter >= maxIter){
		printf("Constraint satisfaction failed!! Iter: %d, y_yPrime: %e\n", newtonsIter, y_yPrime);
	};
	*iter += newtonsIter;
	return x0;
}

double thetasToLambdas(double* thetas, double* lambdas, int nSub, int* newtons) {
	double x0 = findMaxTheta(thetas, nSub) - 1.0;
	double theta0 = newtonsMethod(x0, newtons, thetas, nSub); 

	for (int i = 0; i < nSub; i++) {
		if (thetas[i] >= theta0) {
			double diff = thetas[i] - theta0;
			lambdas[i] = diff * diff * diff;
		}
		else {
			lambdas[i] = 0;
		}
	}
    return theta0;
}

double getBias(double thetas, double beta, double k, double w, int nSub) {
	double bias = 0;
	if (thetas <= (-nSub * w)) {
		double dist = (thetas + (nSub * w));
		bias = 0.5 * (k / beta) * dist * dist;
	} else if (thetas >= (nSub * w)) {
		double dist = (thetas - (nSub * w));
		bias = 0.5 * (k / beta) * dist * dist;
	} else {
		bias = 0;
	}
	// Note beta is not used
	return bias;
}

// function for montecarlo metropolis sampling of pwise constraint 
void metropolis_pw(double* currentThetas, double theta0, double beta, double n, double w, int nSub, double stepSize) {
	for (int i = 0; i < nSub; i++) {
		double delta = 2*(random01()-.5)*stepSize;
		double eOld = getBias(currentThetas[i], beta, n, w, nSub);
		currentThetas[i] += delta;
		double eNew = getBias(currentThetas[i], beta, n, w, nSub);
		if (exp(beta*(eOld - eNew)) <= random01()) { // reject (important for nans)
			currentThetas[i] -= delta;
		} 
	} 
}

// FPL function, does main calculations for FPL, iterations, acceptance probability, etc.
double getFPL(int nSub, int steps, double w, double n, double beta, double eps, double* fpl_path) {
	double* thetas = (double*) calloc(nSub, sizeof(double));
	double* lambdas = (double*) calloc(nSub, sizeof(double));
	double* percent_phys = (double*) calloc(nSub+1, sizeof(double));
	double physical = 0.0;
	double path = 0.0; 
	int newtons = 0;
    double theta0 = thetasToLambdas(thetas, lambdas, nSub, &newtons);

	for (int i = 0; i < steps; i++) {
		metropolis_pw(thetas, theta0, beta, n, w, nSub, nSub*w); // sample much further then nessisary
        theta0 = thetasToLambdas(thetas, lambdas, nSub, &newtons);
		int n_phys = 0;
		for (int j = 0; j < nSub; j++){
			n_phys += lambdas[j] > eps ? 1 : 0;
		}
		percent_phys[n_phys]++; 
	}
	printf("Counts: [ ");
	for(int i = 0; i < nSub+1; i++){
		percent_phys[i] /= steps;
		printf("%f, ", percent_phys[i]);
	}
	printf(" ]\n");

	double analyticFPL = pow((1 - (1 / (2 * nSub * w))), nSub);
	double fractionPhysical =  percent_phys[1];
    double fractionPath = percent_phys[2];
    double other = 1.0 - fractionPath - fractionPhysical;
	double other_steps = other*steps;
	double ave_newtons = newtons / (steps+1.0); // initialized theta0 as well

	std::cout <<  "Ns: " << nSub << ", Cutoff eps: " << eps << ", AnalyticFPL: " << analyticFPL 
    << ", NumericFPL: " << fractionPhysical << ", Path Frac: " << fractionPath << 
	", Rest Frac: " << other << ", Ave Newtons: " << ave_newtons << std::endl;
	printf("\n");

	fpl_path[0] = fractionPhysical;
	fpl_path[1] = fractionPath;

	free(thetas);
	free(lambdas);
	free(percent_phys);

	return fractionPhysical;
}

// main function; change parameters here
// compile with: g++ -O3 -march=native pwise_mc.cpp -o pwise_impl
int main() {
	double kb = (1.987 * 1e-3);
	double T = 298.15; 
	double beta = 1 / (kb*T); 

	// New implicit constraint parameters
	double k = 30; // harmonic constant
	double w = .2; // flat bottom harmonic width

	double eps = 0;

	// Sampling parameters
	int steps = 100000; // MC samples
	int min_Ns = 2;
	int max_Ns = 10;
	int num_Ns = 2; 
	float p = 100;
	float low = pow(min_Ns, 1/p);
	float high = pow(max_Ns, 1/p);
	int* Ns_values = (int*) calloc(num_Ns+1, sizeof(int));
	Ns_values[0] = min_Ns;
	printf("Ns_values: [ %d, ", Ns_values[0]);
	int value = 1;
	for(int i = 1; i <= num_Ns; i++){
		double interp = low + i*(high - low)/num_Ns;
		int val = round(pow(interp, p));
		if(Ns_values[value-1] == val){
			//printf("Skipping repeated entry!! %d\n", val);
			continue; // skip repeated entry
		}
		Ns_values[value] = val;
		printf("%d, ", Ns_values[value]);
		value++;
	}
	num_Ns = value; // only run for unique Ns
	printf("]\n");

	double* fpl_values = (double*) calloc(num_Ns, sizeof(double));
	double* path_values = (double*) calloc(num_Ns, sizeof(double));
	int Ns = 2;
	double fpl_path[2];
	for(int i = 0; i < num_Ns; i++){
		getFPL(Ns_values[i], steps, w, k, beta, eps, fpl_path); 
		fpl_values[i] = fpl_path[0];
		path_values[i] = fpl_path[1];
	}

	// Output sampling data
	printf("Ns: [ ");
	for(int i = 0; i < num_Ns; i++){
		printf("%d, ", Ns_values[i]);
	}
	printf("]\n");
	printf("FPL: [ ");
	for(int i = 0; i < num_Ns; i++){
		printf("%f, ", fpl_values[i]);
	}
	printf("]\n");
	printf("Path: [");
	for(int i = 0; i < num_Ns; i++){
		printf("%f, ", path_values[i]);
	}
	printf("]\n");
	printf("Other: [");
	for(int i = 0; i < num_Ns; i++){
		printf("%f, ", 1 - fpl_values[i] - path_values[i]);
	}
	printf("]\n");
	return 0; 
}
