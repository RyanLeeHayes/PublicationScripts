#include <iostream>	
#include <cmath> 
#include <stdlib.h>
#include <stdio.h>
#include <random> 
#include <utility>
#include <math.h>
#include <random>

using namespace std; 

double random01() {
    static thread_local std::mt19937 gen(std::random_device{}());
    static std::uniform_real_distribution<double> dis(0.0f, 1.0f);
    return dis(gen);
}

int compare_double(const void* a, const void* b) {
	const double* arg1 = (const double*)a;
	const double* arg2 = (const double*)b;
	if (*arg1 < *arg2) return -1;
	if (*arg1 > *arg2) return 1;
	return 0;
}

void metropolis_softmax(int nSub, double* currentThetas, double step_size, double b, double beta) {
	for (int i = 0; i < nSub; i++) {
		double st=(-0.5*sin(currentThetas[i])+0.5);
        double eOld=-b*st*st*st*st;

		double newT = step_size*random01();
		st=(-0.5*sin(newT)+0.5);
        double eNew=-b*st*st*st*st;
		// b contains beta already
		if (exp(eOld - eNew) > random01()) { // accept 
			currentThetas[i] = newT; 
		} 
	} 
}

// FPL function, does main calculations for FPL, iterations, acceptance probability, etc.
double getFPL(int nSub, int steps, bool inde_bias, double b, double c, double beta, double eps, double* fpl_path) {
	double* thetas = (double*) calloc(nSub, sizeof(double));
	// Init thetas
	thetas[0]=M_PI/2;
    for (int i=1; i<nSub; i++) {
      thetas[i]=3*M_PI/2;
    }
	double* lambdas = (double*) calloc(nSub, sizeof(double));
	double physical = 0.0;
	double path = 0.0; 

	for (int i = 0; i < steps; i++) {
		// Sample theta
		if (inde_bias){
			// Metropolized Monte-Carlo
			double step_size = 2*M_PI; // max step size
			metropolis_softmax(nSub, thetas, step_size, b, beta); // updates thetas
		} else {
			// Regular Monte-Carlo
			for(int j = 0; j < nSub; j++){
				thetas[j] = random01()*2*M_PI; 
			}
		}

		// Compute periodic softmax
		double sum = 0;
		for(int j = 0; j < nSub; j++){
			sum += exp(c*sin(thetas[j]));
		}
		for(int j = 0; j < nSub; j++){
			lambdas[j] = exp(c*sin(thetas[j])) / sum;
		}

		// Evaluate cutoffs
		qsort(lambdas, nSub, sizeof(double), compare_double);
		double totalLambdas = 0;
		for (int j = 0; j < nSub; j++) {
			totalLambdas += lambdas[j];
		}
		double others = totalLambdas - lambdas[nSub - 1];
		if (fabs(others) < eps) {
			physical += 1.0;
		}
		else {
			others = totalLambdas - (lambdas[nSub - 1] + lambdas[nSub - 2]);
			if (fabs(others) < eps) {
				path += 1.0;
			}
		}
	}

	double fractionPhysical = physical / steps;
    double fractionPath = path / steps;
    double other = 1.0 - fractionPath - fractionPhysical;
	double other_steps = other*steps;

	std::cout <<  "Ns: " << nSub << ", Cutoff eps: " << eps << ", NumericFPL: " << fractionPhysical << ", Path Frac: " << fractionPath << 
	", Rest Frac: " << other << std::endl;

	fpl_path[0] = fractionPhysical;
	fpl_path[1] = fractionPath;

	return fractionPhysical;
}

// From https://github.com/RyanLeeHayes/ALF/blob/master/alf/lmalf/src/lmalf.cu
double getindependent(int Ns){
	double b = 1;
    for (int i = 0; i < 50; i++) {
      b=0.5*log(0.25*b*Ns*Ns*M_PI/2);
      if (!(b>0)) b=0;
    }
	return b;
}

// main function; change parameters here
// compile with: g++ -O3 -march=native softmax_mc.cpp -o softmax_impl
int main() {
	double k = (1.987 * 1e-3);
	double T = 298.15; 
	double beta = 1.0 / (k*T); 

	// Old implicit parameters
	double c = 5.5;
	bool inde_bias = false;

	// Cutoff eps
	double eps = 1e-2;
	// Sampling parameters
	int steps = 1000000; // MC samples
	int min_Ns = 2;
	int max_Ns = 1000;
	int num_Ns = 20;
	float p = 100;
	float low = pow(min_Ns, 1/p);
	float high = pow(max_Ns, 1/p);
	int* Ns_values = (int*) calloc(num_Ns+1, sizeof(int));
	Ns_values[0] = min_Ns;
	printf("Ns_values: [ %d, ", Ns_values[0]);
	int value = 1;
	for(int i = 1; i <= num_Ns; i++){
		double interp = low + i*(high - low)/num_Ns;
		int val = round(pow(interp, p));
		if(Ns_values[value-1] == val){
			//printf("Skipping repeated entry!! %d\n", val);
			continue; // skip repeated entry
		}
		Ns_values[value] = val;
		printf("%d, ", Ns_values[value]);
		value++;
	}
	num_Ns = value; // only run for unique Ns
	printf("]\n");

	double* fpl_values = (double*) calloc(num_Ns, sizeof(double));
	double fpl_path[2];
	for(int i = 0; i < num_Ns; i++){
		double inde_b = getindependent(Ns_values[i]);
		double num_FPL = getFPL(Ns_values[i], steps, inde_bias, inde_b, c, beta, eps, fpl_path); 
		fpl_values[i] = num_FPL;
	}

	printf("Ns: [ ");
	for(int i = 0; i < num_Ns; i++){
		printf("%d, ", Ns_values[i]);
	}
	printf("]\n");
	printf("FPL: [ ");
	for(int i = 0; i < num_Ns; i++){
		printf("%f, ", fpl_values[i]);
	}
	printf("]\n");
	return 0; 
}
