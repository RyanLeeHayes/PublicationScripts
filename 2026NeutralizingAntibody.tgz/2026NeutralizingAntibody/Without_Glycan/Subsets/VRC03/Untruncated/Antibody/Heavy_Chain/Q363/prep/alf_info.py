import numpy as np
alf_info={}
alf_info['name']='Q363'
alf_info['nsubs']=np.loadtxt('prep/nsubs',dtype='int',ndmin=1)
alf_info['nblocks']=np.sum(alf_info['nsubs'])
alf_info['ncentral']=0
alf_info['nreps']=1
alf_info['nnodes']=1
alf_info['enginepath']='/u/asamadi/NEW/gnu/charmm'
alf_info['temp']=298.15
alf_info['q']=[0,0]
