#!/bin/bash
set -euo pipefail
URL="https://zenodo.org/records/22801816/files/Neutralizing_Antibody_gp120.tar.gz?download=1"
MD5="3f11a42d9063c46dc403389d4dabea59"
curl -L -o Neutralizing_Antibody_gp120.tar.gz "$URL"
echo "$MD5  Neutralizing_Antibody_gp120.tar.gz" | md5sum -c -
tar -xzf Neutralizing_Antibody_gp120.tar.gz
